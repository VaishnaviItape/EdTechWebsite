import React from 'react';

export default function About() {
  return (
    <div>
      <h2>About HireTech</h2>
      <p>We help developers learn the skills to get hired.</p>
    </div>
  );
}
